package com.qrcode.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/generateQR")
public class GenerateQRServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 요청에서 파라미터 가져오기
        request.setCharacterEncoding("UTF-8");
        String content = request.getParameter("content");
        String size = request.getParameter("size");
        
        // 파라미터 검증
        if (content == null || content.trim().isEmpty()) {
            response.sendRedirect("index.jsp");
            return;
        }
        
        // QR 코드 생성 완료 표시
        request.setAttribute("qrCodeGenerated", true);
        
        // 결과 페이지로 포워드
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}

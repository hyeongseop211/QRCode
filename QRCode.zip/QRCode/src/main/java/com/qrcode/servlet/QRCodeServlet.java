package com.qrcode.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

@WebServlet("/qrcode")
public class QRCodeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 요청에서 파라미터 가져오기
        request.setCharacterEncoding("UTF-8");
        String content = request.getParameter("content");
        String sizeStr = request.getParameter("size");
        
        // 파라미터 검증
        if (content == null || content.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "내용을 입력해주세요");
            return;
        }
        
        // 기본 크기 설정
        int size = 250;
        if (sizeStr != null && !sizeStr.isEmpty()) {
            try {
                size = Integer.parseInt(sizeStr);
                // 크기 제한 (너무 크거나 작지 않게)
                if (size < 50) size = 50;
                if (size > 1000) size = 1000;
            } catch (NumberFormatException e) {
                // 숫자 형식이 아닌 경우 기본값 사용
                size = 250;
            }
        }
        
        try {
            // QR 코드 생성 옵션 설정
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H); // 높은 오류 수정 레벨
            hints.put(EncodeHintType.MARGIN, 1); // 여백 설정
            
            // QR 코드 생성
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(content, BarcodeFormat.QR_CODE, size, size, hints);
            
            // 응답 설정
            response.setContentType("image/png");
            response.setHeader("Cache-Control", "no-cache");
            response.setDateHeader("Expires", 0);
            
            // QR 코드 이미지를 응답 스트림에 쓰기
            ServletOutputStream outputStream = response.getOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", outputStream);
            outputStream.flush();
            
        } catch (WriterException e) {
            throw new ServletException("QR 코드 생성 중 오류가 발생했습니다.", e);
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}
